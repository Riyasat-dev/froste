import { Component, Suspense, useEffect, useMemo, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Sparkles, useGLTF } from "@react-three/drei";
import * as THREE from "three";

/* ------------------------------------------------------------------
   Procedural garments + hanger (placeholder until real GLB models).
   Origin (0,0) = bottom of the hanger hook; garment hangs below it.
   ------------------------------------------------------------------ */

// Right-half silhouette points: neck -> shoulder -> sleeve -> cuff -> underarm -> body -> hem corner
const SPECS = {
  puffer: {
    hem: -2.55,
    depth: 0.34,
    bevel: 0.09,
    rough: 0.45,
    half: [
      [0.3, -0.4],
      [0.62, -0.46],
      [0.95, -0.7],
      [1.25, -1.4],
      [1.55, -2.2],
      [1.2, -2.32],
      [0.84, -1.3],
      [0.8, -1.9],
      [0.84, -2.55],
    ],
  },
  coat: {
    hem: -3.4,
    depth: 0.2,
    bevel: 0.045,
    rough: 0.95,
    half: [
      [0.28, -0.42],
      [0.7, -0.5],
      [1.0, -0.68],
      [1.15, -1.4],
      [1.28, -2.5],
      [1.04, -2.56],
      [0.8, -1.35],
      [0.76, -2.2],
      [0.9, -3.4],
    ],
  },
  knit: {
    hem: -2.35,
    depth: 0.24,
    bevel: 0.06,
    rough: 1,
    half: [
      [0.28, -0.42],
      [0.65, -0.5],
      [0.98, -0.72],
      [1.12, -1.5],
      [1.28, -2.35],
      [1.0, -2.42],
      [0.76, -1.3],
      [0.74, -2.35],
    ],
  },
};

function buildOutline(spec) {
  const right = spec.half;
  const left = right.map(([x, y]) => [-x, y]).reverse();
  const pts = [[0, -0.6], ...right, [0, spec.hem], ...left].map(
    ([x, y]) => new THREE.Vector3(x, y, 0),
  );
  const curve = new THREE.CatmullRomCurve3(pts, true, "centripetal");
  return curve
    .getPoints(220)
    .slice(0, -1)
    .map((p) => new THREE.Vector2(p.x, p.y));
}

function Garment({ type, color }) {
  const spec = SPECS[type];

  const { geo, shadowGeo } = useMemo(() => {
    const shape = new THREE.Shape(buildOutline(spec));
    const g = new THREE.ExtrudeGeometry(shape, {
      depth: spec.depth,
      bevelEnabled: true,
      bevelThickness: spec.bevel * 0.8,
      bevelSize: spec.bevel,
      bevelSegments: 6,
      curveSegments: 1,
      steps: 1,
    });
    g.translate(0, 0, -spec.depth / 2);
    return { geo: g, shadowGeo: new THREE.ShapeGeometry(shape) };
  }, [spec]);

  useEffect(
    () => () => {
      geo.dispose();
      shadowGeo.dispose();
    },
    [geo, shadowGeo],
  );

  const dark = useMemo(() => new THREE.Color(color).multiplyScalar(0.7), [color]);
  const front = spec.depth / 2 + spec.bevel * 0.8 + 0.004;
  const bodyHalf = spec.half[spec.half.length - 1][0];

  return (
    <group>
      <mesh geometry={geo}>
        <meshStandardMaterial color={color} roughness={spec.rough} metalness={type === "puffer" ? 0.08 : 0} />
      </mesh>

      {/* collar / neck band */}
      <mesh position={[0, -0.47, 0]} scale={type === "coat" ? [0.36, 0.15, 0.17] : [0.42, 0.17, 0.25]}>
        <sphereGeometry args={[1, 24, 16]} />
        <meshStandardMaterial color={dark} roughness={1} />
      </mesh>

      {type === "puffer" && (
        <>
          {[-1.0, -1.38, -1.76, -2.14, -2.5].map((y) => (
            <mesh key={y} position={[0, y, front]}>
              <boxGeometry args={[bodyHalf * 2 - 0.06, 0.022, 0.012]} />
              <meshStandardMaterial color={dark} roughness={0.7} />
            </mesh>
          ))}
          <mesh position={[0, (-0.6 + spec.hem) / 2, front + 0.004]}>
            <boxGeometry args={[0.03, Math.abs(spec.hem + 0.6), 0.012]} />
            <meshStandardMaterial color="#8f8f8f" metalness={0.8} roughness={0.35} />
          </mesh>
        </>
      )}

      {type === "coat" && (
        <>
          {[1, -1].map((s) => (
            <mesh key={s} position={[0, 0, front]}>
              <shapeGeometry
                args={[
                  new THREE.Shape([
                    new THREE.Vector2(s * 0.34, -0.4),
                    new THREE.Vector2(s * 0.08, -1.25),
                    new THREE.Vector2(s * 0.0, -0.62),
                  ]),
                ]}
              />
              <meshStandardMaterial color={dark} roughness={1} side={THREE.DoubleSide} />
            </mesh>
          ))}
          {[-1.35, -1.95, -2.55].map((y) =>
            [-0.2, 0.2].map((x) => (
              <mesh key={`${x}-${y}`} position={[x, y, front + 0.02]}>
                <sphereGeometry args={[0.05, 16, 12]} />
                <meshStandardMaterial color="#2b2a27" roughness={0.4} />
              </mesh>
            ))
          )}
        </>
      )}

      {type === "knit" && (
        <mesh position={[0, spec.hem + 0.13, 0]}>
          <boxGeometry args={[bodyHalf * 2 + spec.bevel * 2 + 0.04, 0.26, spec.depth + spec.bevel * 1.6 + 0.04]} />
          <meshStandardMaterial color={dark} roughness={1} />
        </mesh>
      )}
    </group>
  );
}


/* ------------------------------------------------------------------
   Real GLB garments (built by the pipeline in /tools). They are already
   scaled, centred and posed for the hanger, so nothing is fitted here.
   Material roles live in material.extras: body | trim | tape | metal | fixed.
   Colour swatches tint the "body"/"trim" materials.
   ------------------------------------------------------------------ */
function ModelGarment({ url, color }) {
  const { scene } = useGLTF(url);

  const { root, mats } = useMemo(() => {
    const root = scene.clone(true);
    const mats = [];
    root.traverse((o) => {
      if (!o.isMesh) return;
      const m = o.material.clone();
      mats.push(m);
      o.material = m;
    });
    return { root, mats };
  }, [scene]);

  useEffect(() => {
    const base = new THREE.Color(color);
    mats.forEach((m) => {
      const role = m.userData.role;
      const rough = m.userData.rough ?? 0.8;
      if (role === "fixed") {
        m.roughness = rough;
      } else if (role === "metal") {
        m.color.set("#9a9a9a");
        m.roughness = 0.35;
        m.metalness = 0.85;
      } else {
        const k = role === "trim" ? 0.85 : role === "tape" ? 0.55 : 1;
        m.color.copy(base).multiplyScalar(k);
        m.roughness = rough;
        m.metalness = 0.04;
      }
    });
  }, [mats, color]);

  useEffect(() => () => mats.forEach((m) => m.dispose()), [mats]);

  return <primitive object={root} />;
}

// If a model fails to load (404, bad file) fall back to the procedural garment.
class ModelBoundary extends Component {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch(err) {
    console.warn("GLB failed to load, using procedural garment instead:", err);
  }
  render() {
    return this.state.failed ? this.props.fallback : this.props.children;
  }
}

export function GarmentSwitch({ type, color, model }) {
  const procedural = <Garment type={type} color={color} />;
  if (!model) return procedural;
  return (
    <ModelBoundary fallback={procedural}>
      <Suspense fallback={procedural}>
        <ModelGarment url={model.url} color={color} />
      </Suspense>
    </ModelBoundary>
  );
}

function Hanger() {
  const hook = useMemo(() => {
    const curve = new THREE.CatmullRomCurve3(
      [
        [0, -0.32, 0],
        [0, -0.05, 0],
        [0.02, 0.12, 0],
        [0.1, 0.26, 0],
        [0.02, 0.36, 0],
        [-0.07, 0.3, 0],
        [-0.06, 0.22, 0],
      ].map(([x, y, z]) => new THREE.Vector3(x, y, z)),
    );
    return new THREE.TubeGeometry(curve, 48, 0.018, 8, false);
  }, []);
  useEffect(() => () => hook.dispose(), [hook]);

  const armLen = Math.hypot(0.92, 0.27);
  const armAngle = Math.atan2(0.27, 0.92);

  return (
    <group>
      <mesh geometry={hook}>
        <meshStandardMaterial color="#8b8b8b" metalness={0.9} roughness={0.3} />
      </mesh>
      {[1, -1].map((s) => (
        <mesh key={s} position={[s * 0.46, -0.435, 0]} rotation={[0, 0, -s * armAngle]}>
          <boxGeometry args={[armLen, 0.06, 0.08]} />
          <meshStandardMaterial color="#9a7350" roughness={0.55} />
        </mesh>
      ))}
    </group>
  );
}

const PIVOT_Y = 0.32;
export const DROP = -0.1; // negative = garment is raised so the hanger arms sit inside its shoulders
const LIFT = 0.14;
const damp = THREE.MathUtils.damp;

function Scene({ type, color, tilt, active, seed, snow, cy, model }) {
  const shadowBase = model ? 0.17 : 0.075;
  const shadowDrop = model ? 0.12 : 0.035;
  // GLB garments get a soft elliptical shadow (a silhouette copy would not match their shape)
  const blobTex = useMemo(() => {
    const cv = document.createElement("canvas");
    cv.width = cv.height = 128;
    const ctx = cv.getContext("2d");
    const g = ctx.createRadialGradient(64, 64, 4, 64, 64, 62);
    g.addColorStop(0, "rgba(255,255,255,1)");
    g.addColorStop(0.55, "rgba(255,255,255,0.55)");
    g.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 128, 128);
    return new THREE.CanvasTexture(cv);
  }, []);
  useEffect(() => () => blobTex.dispose(), [blobTex]);
  const blobH = model ? (0.3 - (model.bottom - DROP)) * 1.08 : 0;
  const blobY = model ? (-0.3 + (model.bottom - DROP)) / 2 - PIVOT_Y : 0;
  const pivot = useRef();
  const shadowPivot = useRef();
  const shadowMat = useRef();
  const keyLight = useRef();
  const spec = SPECS[type];
  const shadowGeo = useMemo(
    () => new THREE.ShapeGeometry(new THREE.Shape(buildOutline(spec))),
    [spec],
  );
  useEffect(() => () => shadowGeo.dispose(), [shadowGeo]);

  useFrame((state, delta) => {
    const dt = Math.min(delta, 0.05);
    const t = state.clock.elapsedTime;
    const P = pivot.current;
    if (!P) return;

    const sway = Math.sin(t * 0.8 + seed) * 0.03;
    const targetZ = active ? Math.sin(t * 1.2 + seed) * 0.008 : tilt + sway;
    const targetYaw = active ? 0 : -tilt * 2.2 + sway * 2;
    const targetLift = active ? LIFT + Math.sin(t * 1.5 + seed) * 0.02 : Math.sin(t * 1.1 + seed) * 0.008;
    const targetScale = active ? 1.04 : 1;

    P.rotation.z = damp(P.rotation.z, targetZ, 3.2, dt);
    P.rotation.y = damp(P.rotation.y, targetYaw, 3.2, dt);
    P.position.y = damp(P.position.y, PIVOT_Y + targetLift, 3.5, dt);
    const s = damp(P.scale.x, targetScale, 3.5, dt);
    P.scale.set(s, s, s);

    const lift = THREE.MathUtils.clamp((P.position.y - PIVOT_Y) / LIFT, 0, 1);
    const S = shadowPivot.current;
    S.rotation.z = P.rotation.z;
    S.scale.set(Math.max(0.55, Math.abs(Math.cos(P.rotation.y))) * s, s, 1);
    S.position.x = 0.16 + lift * 0.12;
    S.position.y = P.position.y - 0.05 - lift * 0.07;
    shadowMat.current.opacity = shadowBase - lift * shadowDrop;

    keyLight.current.intensity = damp(keyLight.current.intensity, active ? 2.5 : 1.7, 3, dt);
  });

  return (
    <>
      <hemisphereLight args={["#ffffff", "#d8d0c3", 1.0]} />
      <directionalLight ref={keyLight} position={[2.5, 3, 5]} intensity={1.7} />
      <directionalLight position={[-3, 1, -2]} intensity={0.6} />

      {snow && (
        <Sparkles count={70} scale={[6, 6, 3]} position={[0, cy, 0.5]} size={4} speed={0.35} opacity={0.9} color="#ffffff" />
      )}

      {/* soft fake wall shadow */}
      <group ref={shadowPivot} position={[0.16, PIVOT_Y, -0.9]}>
        {model ? (
          <mesh position={[0, blobY, 0]}>
            <planeGeometry args={[3.1, blobH]} />
            <meshBasicMaterial ref={shadowMat} map={blobTex} color="#292824" transparent opacity={shadowBase} depthWrite={false} />
          </mesh>
        ) : (
          [1, 1.035, 1.07].map((k) => (
            <mesh key={k} geometry={shadowGeo} position={[0, -PIVOT_Y - DROP, 0]} scale={[k, k, 1]}>
              {k === 1 ? (
                <meshBasicMaterial ref={shadowMat} color="#292824" transparent opacity={shadowBase} depthWrite={false} />
              ) : (
                <meshBasicMaterial color="#292824" transparent opacity={0.04} depthWrite={false} />
              )}
            </mesh>
          ))
        )}
      </group>

      <group ref={pivot} position={[0, PIVOT_Y, 0]}>
        <group position={[0, -PIVOT_Y, 0]}>
          <Hanger />
          <group position={[0, -DROP, 0]}>
            <GarmentSwitch type={type} color={color} model={model} />
          </group>
        </group>
      </group>
    </>
  );
}

// camera distance per garment so the full silhouette (incl. sleeves) fits the frame
const CAMERA_Z = { puffer: 10.2, coat: 9.2, knit: 8.6 };

export default function HangingGarment({ type = "puffer", color = "#cbbfae", tilt = -0.2, active = false, seed = 0, snow = false, zoomOut = 1, model = null }) {
  const bottom = model ? model.bottom : SPECS[type].hem;
  const cy = (0.55 + bottom - DROP) / 2;
  // visible height needed (garment + margin); 0.5735 = 2*tan(fov/2) for fov 32
  const camZ = model
    ? (Math.max(4.6, 0.55 - (bottom - DROP) + 1.4) / 0.5735) * zoomOut
    : CAMERA_Z[type] * zoomOut;
  return (
    <Canvas
      flat
      dpr={[1, 1.75]}
      camera={{ position: [0, cy, camZ], fov: 32 }}
      gl={{ alpha: true, antialias: true }}
      onCreated={({ camera }) => camera.lookAt(0, cy, 0)}
    >
      <Scene type={type} color={color} tilt={tilt} active={active} seed={seed} snow={snow} cy={cy} model={model} />
    </Canvas>
  );
}

export { SPECS, Garment, Hanger };
