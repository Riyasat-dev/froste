import { lazy, Suspense, useRef, useState } from "react";
import { motion, useInView } from "framer-motion";

const HangingGarment = lazy(() => import("./HangingGarment"));

function Campaign() {
  const [active, setActive] = useState(false);
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "200px" });

  return (
    <section
      id="campaign"
      ref={ref}
      className="relative overflow-hidden bg-[#292824] px-6 py-24 md:px-16 md:py-0"
    >
      <div className="mx-auto grid min-h-[640px] max-w-[1440px] items-center gap-10 md:grid-cols-2">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.8 }}
          className="relative z-10"
        >
          <p className="mb-6 text-[10px] tracking-[4px] text-[#d8d0c3]/70">THE WINTER CAMPAIGN</p>
          <h2 className="font-serif text-5xl leading-[1.05] text-[#f5f3ef] md:text-7xl">
            Layers for the
            <br />
            longest nights.
          </h2>
          <p className="mt-7 max-w-sm text-sm leading-7 text-[#d8d0c3]/80">
            Soft knits, deep colour and quiet texture. A season of pieces made to be lived in.
          </p>
          <a
            href="#collection"
            className="mt-9 inline-flex border border-[#f5f3ef]/60 px-9 py-4 text-xs tracking-[2px] text-[#f5f3ef] transition hover:bg-[#f5f3ef] hover:text-[#292824]"
          >
            SHOP THE CAMPAIGN →
          </a>
        </motion.div>

        <div
          role="img"
          aria-label="A burgundy knit sweater on a wooden hanger"
          onPointerEnter={(e) => e.pointerType === "mouse" && setActive(true)}
          onPointerLeave={(e) => e.pointerType === "mouse" && setActive(false)}
          onPointerUp={(e) => e.pointerType !== "mouse" && setActive((a) => !a)}
          className="relative h-[520px] touch-pan-y md:h-[640px]"
        >
          {inView && (
            <Suspense fallback={null}>
              <HangingGarment type="knit" color="#8a3d45" tilt={0.18} seed={4} active={active} snow />
            </Suspense>
          )}
        </div>
      </div>
    </section>
  );
}

export default Campaign;
