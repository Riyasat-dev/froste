import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Collection from "./components/Collection";
import BrandStory from "./components/BrandStory";
import Campaign from "./components/Campaign";
import Newsletter from "./components/Newsletter";
import Footer from "./components/Footer";
import CartDrawer from "./components/CartDrawer";

function App() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <Collection />
        <BrandStory />
        <Campaign />
        <Newsletter />
      </main>
      <Footer />
      <CartDrawer />
    </>
  );
}

export default App;
