// `type` decides which procedural garment is drawn (puffer | coat | knit).
// When real GLB models are ready, add a `model` path here and swap them in HangingGarment.
const products = [
  {
    id: 1,
    name: "The Alpine Puffer",
    category: "Jackets",
    type: "puffer",
    price: 189,
    tilt: -0.22,
    badge: "BESTSELLER",
    colors: [
      { name: "Stone Beige", hex: "#cbbfae" },
      { name: "Burgundy", hex: "#8a3d45" },
      { name: "Charcoal", hex: "#3a3935" },
    ],
  },
  {
    id: 2,
    name: "The Heritage Wool Coat",
    category: "Coats",
    type: "coat",
    price: 249,
    tilt: 0.16,
    badge: "NEW ARRIVAL",
    colors: [
      { name: "Warm Camel", hex: "#b98b5e" },
      { name: "Charcoal", hex: "#4a4842" },
      { name: "Ivory", hex: "#e8e2d6" },
    ],
  },
  {
    id: 3,
    name: "The Cloud Knit",
    category: "Sweaters",
    type: "knit",
    price: 129,
    tilt: -0.14,
    badge: "",
    colors: [
      { name: "Soft Ivory", hex: "#ece6d9" },
      { name: "Oat", hex: "#cdbfa7" },
      { name: "Burgundy", hex: "#8a3d45" },
    ],
  },
  {
    id: 4,
    name: "The Urban Puffer",
    category: "Jackets",
    type: "puffer",
    price: 199,
    tilt: 0.2,
    badge: "LIMITED",
    colors: [
      { name: "Midnight Black", hex: "#2b2a27" },
      { name: "Soft Grey", hex: "#a8a49c" },
      { name: "Stone Beige", hex: "#cbbfae" },
    ],
  },
];

export default products;
