import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Collection from "./components/Collection";
import CartDrawer from "./components/CartDrawer";

function App() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <Collection />
      </main>
      <CartDrawer />
    </>
  );
}

export default App;
