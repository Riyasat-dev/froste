// `type` decides which procedural garment is drawn (puffer | coat | knit).
// When real GLB models are ready, add a `model` path here and swap them in HangingGarment.
const c = (name, hex) => ({ name, hex });

const products = [
  { id: 1, name: "The Alpine Puffer", category: "Jackets", type: "puffer", price: 189, tilt: -0.22, badge: "BESTSELLER",
    colors: [c("Stone Beige", "#cbbfae"), c("Burgundy", "#8a3d45"), c("Charcoal", "#3a3935")] },
  { id: 2, name: "The Heritage Wool Coat", category: "Coats", type: "coat", price: 249, tilt: 0.16, badge: "NEW ARRIVAL",
    colors: [c("Warm Camel", "#b98b5e"), c("Charcoal", "#4a4842"), c("Ivory", "#e8e2d6")] },
  { id: 3, name: "The Cloud Knit", category: "Sweaters", type: "knit", price: 129, tilt: -0.14, badge: "",
    colors: [c("Soft Ivory", "#ece6d9"), c("Oat", "#cdbfa7"), c("Burgundy", "#8a3d45")] },
  { id: 4, name: "The Urban Puffer", category: "Jackets", type: "puffer", price: 199, tilt: 0.2, badge: "LIMITED",
    colors: [c("Midnight Black", "#2b2a27"), c("Soft Grey", "#a8a49c"), c("Stone Beige", "#cbbfae")] },
  { id: 5, name: "The Glacier Puffer", category: "Jackets", type: "puffer", price: 209, tilt: -0.18, badge: "NEW ARRIVAL",
    colors: [c("Frost Blue", "#9fb3bd"), c("Soft Ivory", "#ece6d9"), c("Charcoal", "#3a3935")] },
  { id: 6, name: "The Highland Overcoat", category: "Coats", type: "coat", price: 279, tilt: 0.12, badge: "",
    colors: [c("Charcoal", "#4a4842"), c("Warm Camel", "#b98b5e"), c("Burgundy", "#8a3d45")] },
  { id: 7, name: "The Fjord Knit", category: "Sweaters", type: "knit", price: 139, tilt: 0.18, badge: "BESTSELLER",
    colors: [c("Forest", "#4f5d4a"), c("Oat", "#cdbfa7"), c("Charcoal", "#3a3935")] },
  { id: 8, name: "The Nordic Puffer", category: "Jackets", type: "puffer", price: 219, tilt: -0.16, badge: "",
    colors: [c("Warm Camel", "#b98b5e"), c("Midnight Black", "#2b2a27"), c("Soft Grey", "#a8a49c")] },
  { id: 9, name: "The Atelier Coat", category: "Coats", type: "coat", price: 269, tilt: -0.2, badge: "LIMITED",
    colors: [c("Ivory", "#e8e2d6"), c("Midnight Black", "#2b2a27"), c("Soft Grey", "#a8a49c")] },
  { id: 10, name: "The Ember Knit", category: "Sweaters", type: "knit", price: 119, tilt: 0.14, badge: "",
    colors: [c("Burgundy", "#8a3d45"), c("Soft Ivory", "#ece6d9"), c("Frost Blue", "#9fb3bd")] },
];

export default products;
