import { useEffect, useRef } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { Garment, Hanger } from "./HangingGarment";

const SPACING = 1.15; // distance between hangers (garments overlap a little, like a real closet)
const SCALE = 0.62;
const RAIL_Y = 1.55;
const damp = THREE.MathUtils.damp;

function RailItem({ item, index, activeIdx, onHover, onPick }) {
  const outer = useRef();
  const pivot = useRef();
  const active = activeIdx === index;
  const seed = index * 1.37;

  useFrame((state, delta) => {
    const dt = Math.min(delta, 0.05);
    const t = state.clock.elapsedTime;
    const side = activeIdx == null ? 0 : Math.sign(index - activeIdx);

    // neighbours slide apart, the chosen piece is pulled forward
    outer.current.position.x = damp(outer.current.position.x, index * SPACING + side * 0.4, 4, dt);
    outer.current.position.z = damp(outer.current.position.z, active ? 1.5 : 0, 4, dt);

    const yaw = active ? 0 : 0.95 + Math.sin(seed) * 0.08;
    const roll = active ? 0 : item.tilt * 0.25 + Math.sin(t * 0.8 + seed) * 0.03;
    pivot.current.rotation.y = damp(pivot.current.rotation.y, yaw, 4, dt);
    pivot.current.rotation.z = damp(pivot.current.rotation.z, roll, 4, dt);
    pivot.current.position.y = damp(pivot.current.position.y, active ? 0.18 : 0, 4, dt);
  });

  return (
    <group
      ref={outer}
      position={[index * SPACING, 0, 0]}
      onPointerOver={(e) => {
        e.stopPropagation();
        onHover(index);
      }}
      onPointerOut={() => onHover(null)}
      onClick={(e) => {
        e.stopPropagation();
        if (e.delta > 6) return; // it was a drag, not a tap
        onPick(index);
      }}
    >
      <group ref={pivot}>
        <group scale={SCALE} position={[0, -0.34 * SCALE, 0]}>
          <Hanger />
          <group position={[0, -0.1, 0]}>
            <Garment type={item.type} color={item.hex} />
          </group>
        </group>
      </group>
    </group>
  );
}

function Rail({ items, activeIdx, onHover, onPick, scrollRef, metaRef }) {
  const { viewport } = useThree();
  const railRef = useRef();
  const smooth = useRef(0);

  const viewW = viewport.width;
  const startX = -viewW / 2 + 1.0;
  const maxScroll = Math.max(0, (items.length - 1) * SPACING + 2.0 - viewW);

  useEffect(() => {
    metaRef.current.viewW = viewW;
    metaRef.current.maxScroll = maxScroll;
    scrollRef.current = Math.min(scrollRef.current, maxScroll);
  }, [viewW, maxScroll, metaRef, scrollRef]);

  useFrame((_, delta) => {
    smooth.current = damp(smooth.current, scrollRef.current, 5, Math.min(delta, 0.05));
    railRef.current.position.x = startX - smooth.current;
  });

  return (
    <>
      <hemisphereLight args={["#ffffff", "#d8d0c3", 1.0]} />
      <directionalLight position={[2.5, 3, 5]} intensity={1.8} />
      <directionalLight position={[-3, 1, -2]} intensity={0.6} />

      {/* the closet rod */}
      <mesh position={[0, RAIL_Y, 0]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.03, 0.03, viewW + 6, 16]} />
        <meshStandardMaterial color="#9a9a9a" metalness={0.9} roughness={0.3} />
      </mesh>

      <group ref={railRef} position={[startX, RAIL_Y, 0]}>
        {items.map((item, i) => (
          <RailItem key={item.id} item={item} index={i} activeIdx={activeIdx} onHover={onHover} onPick={onPick} />
        ))}
      </group>
    </>
  );
}

export default function GarmentRail({ items, activeIdx, onHover, onPick, onMiss, scrollRef, metaRef }) {
  return (
    <Canvas
      flat
      dpr={[1, 1.75]}
      camera={{ position: [0, 0, 9], fov: 32 }}
      gl={{ alpha: true, antialias: true }}
      onPointerMissed={onMiss}
    >
      <Rail items={items} activeIdx={activeIdx} onHover={onHover} onPick={onPick} scrollRef={scrollRef} metaRef={metaRef} />
    </Canvas>
  );
}
