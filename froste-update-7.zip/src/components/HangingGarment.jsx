import { Component, Suspense, useEffect, useMemo, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Sparkles, useGLTF } from "@react-three/drei";
import * as THREE from "three";

/* ------------------------------------------------------------------
   Procedural garments + hanger (placeholder until real GLB models).
   Origin (0,0) = bottom of the hanger hook; garment hangs below it.
   ------------------------------------------------------------------ */

// Right-half silhouette points: neck -> shoulder -> sleeve -> cuff -> underarm -> body -> hem corner
const SPECS = {
  puffer: {
    hem: -2.55,
    depth: 0.34,
    bevel: 0.09,
    rough: 0.45,
    half: [
      [0.3, -0.4],
      [0.62, -0.46],
      [0.95, -0.7],
      [1.25, -1.4],
      [1.55, -2.2],
      [1.2, -2.32],
      [0.84, -1.3],
      [0.8, -1.9],
      [0.84, -2.55],
    ],
  },
  coat: {
    hem: -3.4,
    depth: 0.2,
    bevel: 0.045,
    rough: 0.95,
    half: [
      [0.28, -0.42],
      [0.7, -0.5],
      [1.0, -0.68],
      [1.15, -1.4],
      [1.28, -2.5],
      [1.04, -2.56],
      [0.8, -1.35],
      [0.76, -2.2],
      [0.9, -3.4],
    ],
  },
  knit: {
    hem: -2.35,
    depth: 0.24,
    bevel: 0.06,
    rough: 1,
    half: [
      [0.28, -0.42],
      [0.65, -0.5],
      [0.98, -0.72],
      [1.12, -1.5],
      [1.28, -2.35],
      [1.0, -2.42],
      [0.76, -1.3],
      [0.74, -2.35],
    ],
  },
};

function buildOutline(spec) {
  const right = spec.half;
  const left = right.map(([x, y]) => [-x, y]).reverse();
  const pts = [[0, -0.6], ...right, [0, spec.hem], ...left].map(
    ([x, y]) => new THREE.Vector3(x, y, 0),
  );
  const curve = new THREE.CatmullRomCurve3(pts, true, "centripetal");
  return curve
    .getPoints(220)
    .slice(0, -1)
    .map((p) => new THREE.Vector2(p.x, p.y));
}

function Garment({ type, color }) {
  const spec = SPECS[type];

  const { geo, shadowGeo } = useMemo(() => {
    const shape = new THREE.Shape(buildOutline(spec));
    const g = new THREE.ExtrudeGeometry(shape, {
      depth: spec.depth,
      bevelEnabled: true,
      bevelThickness: spec.bevel * 0.8,
      bevelSize: spec.bevel,
      bevelSegments: 6,
      curveSegments: 1,
      steps: 1,
    });
    g.translate(0, 0, -spec.depth / 2);
    return { geo: g, shadowGeo: new THREE.ShapeGeometry(shape) };
  }, [spec]);

  useEffect(
    () => () => {
      geo.dispose();
      shadowGeo.dispose();
    },
    [geo, shadowGeo],
  );

  const dark = useMemo(() => new THREE.Color(color).multiplyScalar(0.7), [color]);
  const front = spec.depth / 2 + spec.bevel * 0.8 + 0.004;
  const bodyHalf = spec.half[spec.half.length - 1][0];

  return (
    <group>
      <mesh geometry={geo}>
        <meshStandardMaterial color={color} roughness={spec.rough} metalness={type === "puffer" ? 0.08 : 0} />
      </mesh>

      {/* collar / neck band */}
      <mesh position={[0, -0.47, 0]} scale={type === "coat" ? [0.36, 0.15, 0.17] : [0.42, 0.17, 0.25]}>
        <sphereGeometry args={[1, 24, 16]} />
        <meshStandardMaterial color={dark} roughness={1} />
      </mesh>

      {type === "puffer" && (
        <>
          {[-1.0, -1.38, -1.76, -2.14, -2.5].map((y) => (
            <mesh key={y} position={[0, y, front]}>
              <boxGeometry args={[bodyHalf * 2 - 0.06, 0.022, 0.012]} />
              <meshStandardMaterial color={dark} roughness={0.7} />
            </mesh>
          ))}
          <mesh position={[0, (-0.6 + spec.hem) / 2, front + 0.004]}>
            <boxGeometry args={[0.03, Math.abs(spec.hem + 0.6), 0.012]} />
            <meshStandardMaterial color="#8f8f8f" metalness={0.8} roughness={0.35} />
          </mesh>
        </>
      )}

      {type === "coat" && (
        <>
          {[1, -1].map((s) => (
            <mesh key={s} position={[0, 0, front]}>
              <shapeGeometry
                args={[
                  new THREE.Shape([
                    new THREE.Vector2(s * 0.34, -0.4),
                    new THREE.Vector2(s * 0.08, -1.25),
                    new THREE.Vector2(s * 0.0, -0.62),
                  ]),
                ]}
              />
              <meshStandardMaterial color={dark} roughness={1} side={THREE.DoubleSide} />
            </mesh>
          ))}
          {[-1.35, -1.95, -2.55].map((y) =>
            [-0.2, 0.2].map((x) => (
              <mesh key={`${x}-${y}`} position={[x, y, front + 0.02]}>
                <sphereGeometry args={[0.05, 16, 12]} />
                <meshStandardMaterial color="#2b2a27" roughness={0.4} />
              </mesh>
            ))
          )}
        </>
      )}

      {type === "knit" && (
        <mesh position={[0, spec.hem + 0.13, 0]}>
          <boxGeometry args={[bodyHalf * 2 + spec.bevel * 2 + 0.04, 0.26, spec.depth + spec.bevel * 1.6 + 0.04]} />
          <meshStandardMaterial color={dark} roughness={1} />
        </mesh>
      )}
    </group>
  );
}


/* ------------------------------------------------------------------
   Real GLB garments. The file is stripped of baked textures, so the colour
   comes from code (swatches keep working). Materials are matched by name.
   Tweak MODEL_FIT if a new model sits too high/low on the hanger.
   ------------------------------------------------------------------ */
const MODEL_FIT = { height: 2.6, topY: -0.25 };

function roleOf(name = "") {
  if (/nylon/i.test(name)) return "body";
  if (/rib/i.test(name)) return "trim";
  if (/fabric/i.test(name)) return "tape";
  return "metal"; // zipper puller / slider / stoppers
}

function ModelGarment({ url, color }) {
  const { scene } = useGLTF(url);

  const { root, scale, offset, mats } = useMemo(() => {
    const root = scene.clone(true);
    const mats = [];
    root.traverse((o) => {
      if (!o.isMesh) return;
      const m = o.material.clone();
      mats.push({ m, role: roleOf(m.name) });
      o.material = m;
    });
    const box = new THREE.Box3().setFromObject(root);
    const size = box.getSize(new THREE.Vector3());
    const center = box.getCenter(new THREE.Vector3());
    const scale = MODEL_FIT.height / size.y;
    return {
      root,
      scale,
      offset: [-center.x * scale, MODEL_FIT.topY - box.max.y * scale, -center.z * scale],
      mats,
    };
  }, [scene]);

  useEffect(() => {
    const base = new THREE.Color(color);
    mats.forEach(({ m, role }) => {
      if (role === "body") {
        m.color.copy(base);
        m.roughness = 0.5;
        m.metalness = 0.05;
      } else if (role === "trim") {
        m.color.copy(base).multiplyScalar(0.8);
        m.roughness = 0.95;
        m.metalness = 0;
      } else if (role === "tape") {
        m.color.copy(base).multiplyScalar(0.55);
        m.roughness = 0.9;
        m.metalness = 0;
      } else {
        m.color.set("#9a9a9a");
        m.roughness = 0.35;
        m.metalness = 0.85;
      }
    });
  }, [mats, color]);

  useEffect(() => () => mats.forEach(({ m }) => m.dispose()), [mats]);

  return (
    <group position={offset} scale={scale}>
      <primitive object={root} />
    </group>
  );
}

// If a model fails to load (404, bad file) fall back to the procedural garment.
class ModelBoundary extends Component {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch(err) {
    console.warn("GLB failed to load, using procedural garment instead:", err);
  }
  render() {
    return this.state.failed ? this.props.fallback : this.props.children;
  }
}

export function GarmentSwitch({ type, color, model }) {
  const procedural = <Garment type={type} color={color} />;
  if (!model) return procedural;
  return (
    <ModelBoundary fallback={procedural}>
      <Suspense fallback={procedural}>
        <ModelGarment url={model} color={color} />
      </Suspense>
    </ModelBoundary>
  );
}

function Hanger() {
  const hook = useMemo(() => {
    const curve = new THREE.CatmullRomCurve3(
      [
        [0, -0.32, 0],
        [0, -0.05, 0],
        [0.02, 0.12, 0],
        [0.1, 0.26, 0],
        [0.02, 0.36, 0],
        [-0.07, 0.3, 0],
        [-0.06, 0.22, 0],
      ].map(([x, y, z]) => new THREE.Vector3(x, y, z)),
    );
    return new THREE.TubeGeometry(curve, 48, 0.018, 8, false);
  }, []);
  useEffect(() => () => hook.dispose(), [hook]);

  const armLen = Math.hypot(1.02, 0.28);
  const armAngle = Math.atan2(0.28, 1.02);

  return (
    <group>
      <mesh geometry={hook}>
        <meshStandardMaterial color="#8b8b8b" metalness={0.9} roughness={0.3} />
      </mesh>
      {[1, -1].map((s) => (
        <mesh key={s} position={[s * 0.51, -0.44, 0]} rotation={[0, 0, -s * armAngle]}>
          <boxGeometry args={[armLen, 0.05, 0.075]} />
          <meshStandardMaterial color="#9a7350" roughness={0.55} />
        </mesh>
      ))}
    </group>
  );
}

const PIVOT_Y = 0.32;
export const DROP = 0.1; // garment hangs slightly below the hanger arms so they stay visible
const LIFT = 0.14;
const damp = THREE.MathUtils.damp;

function Scene({ type, color, tilt, active, seed, snow, cy, model }) {
  const shadowK = model ? [0.76, 0.95] : [1, 1]; // GLB jackets are narrower than the procedural outline
  const pivot = useRef();
  const shadowPivot = useRef();
  const shadowMat = useRef();
  const keyLight = useRef();
  const spec = SPECS[type];
  const shadowGeo = useMemo(
    () => new THREE.ShapeGeometry(new THREE.Shape(buildOutline(spec))),
    [spec],
  );
  useEffect(() => () => shadowGeo.dispose(), [shadowGeo]);

  useFrame((state, delta) => {
    const dt = Math.min(delta, 0.05);
    const t = state.clock.elapsedTime;
    const P = pivot.current;
    if (!P) return;

    const sway = Math.sin(t * 0.8 + seed) * 0.03;
    const targetZ = active ? Math.sin(t * 1.2 + seed) * 0.008 : tilt + sway;
    const targetYaw = active ? 0 : -tilt * 2.2 + sway * 2;
    const targetLift = active ? LIFT + Math.sin(t * 1.5 + seed) * 0.02 : Math.sin(t * 1.1 + seed) * 0.008;
    const targetScale = active ? 1.04 : 1;

    P.rotation.z = damp(P.rotation.z, targetZ, 3.2, dt);
    P.rotation.y = damp(P.rotation.y, targetYaw, 3.2, dt);
    P.position.y = damp(P.position.y, PIVOT_Y + targetLift, 3.5, dt);
    const s = damp(P.scale.x, targetScale, 3.5, dt);
    P.scale.set(s, s, s);

    const lift = THREE.MathUtils.clamp((P.position.y - PIVOT_Y) / LIFT, 0, 1);
    const S = shadowPivot.current;
    S.rotation.z = P.rotation.z;
    S.scale.set(Math.max(0.55, Math.abs(Math.cos(P.rotation.y))) * s, s, 1);
    S.position.x = 0.16 + lift * 0.12;
    S.position.y = P.position.y - 0.05 - lift * 0.07;
    shadowMat.current.opacity = 0.075 - lift * 0.035;

    keyLight.current.intensity = damp(keyLight.current.intensity, active ? 2.5 : 1.7, 3, dt);
  });

  return (
    <>
      <hemisphereLight args={["#ffffff", "#d8d0c3", 1.0]} />
      <directionalLight ref={keyLight} position={[2.5, 3, 5]} intensity={1.7} />
      <directionalLight position={[-3, 1, -2]} intensity={0.6} />

      {snow && (
        <Sparkles count={70} scale={[6, 6, 3]} position={[0, cy, 0.5]} size={4} speed={0.35} opacity={0.9} color="#ffffff" />
      )}

      {/* soft fake wall shadow */}
      <group ref={shadowPivot} position={[0.16, PIVOT_Y, -0.9]}>
        {[1, 1.035, 1.07].map((k) => (
          <mesh key={k} geometry={shadowGeo} position={[0, -PIVOT_Y - DROP, 0]} scale={[k * shadowK[0], k * shadowK[1], 1]}>
            {k === 1 ? (
              <meshBasicMaterial ref={shadowMat} color="#292824" transparent opacity={0.075} depthWrite={false} />
            ) : (
              <meshBasicMaterial color="#292824" transparent opacity={0.04} depthWrite={false} />
            )}
          </mesh>
        ))}
      </group>

      <group ref={pivot} position={[0, PIVOT_Y, 0]}>
        <group position={[0, -PIVOT_Y, 0]}>
          <Hanger />
          <group position={[0, -DROP, 0]}>
            <GarmentSwitch type={type} color={color} model={model} />
          </group>
        </group>
      </group>
    </>
  );
}

// camera distance per garment so the full silhouette (incl. sleeves) fits the frame
const CAMERA_Z = { puffer: 9.4, coat: 8.6, knit: 8.4 };

export default function HangingGarment({ type = "puffer", color = "#cbbfae", tilt = -0.2, active = false, seed = 0, snow = false, zoomOut = 1, model = null }) {
  const cy = (0.55 + SPECS[type].hem - DROP) / 2;
  return (
    <Canvas
      flat
      dpr={[1, 1.75]}
      camera={{ position: [0, cy, CAMERA_Z[type] * zoomOut], fov: 32 }}
      gl={{ alpha: true, antialias: true }}
      onCreated={({ camera }) => camera.lookAt(0, cy, 0)}
    >
      <Scene type={type} color={color} tilt={tilt} active={active} seed={seed} snow={snow} cy={cy} model={model} />
    </Canvas>
  );
}

export { SPECS, Garment, Hanger };
